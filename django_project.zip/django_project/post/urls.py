from django.urls import path
from . import views


app_name = 'posts'

urlpatterns = [
    path('', views.index, name='index'),
    path('<int:id>/', views.detail, name='detail'),
    path('<int:id>/comments/', views.comment, name='comment'),
    path('search/', views.search, name='search'),
    path('created/', views.create_post, name='created'),
    path('create/', views.create, name='create'),
    path('sign_up/', views.sign_up, name='sign_up'),
    path('sign_up_your_account/', views.sign_up_your_account, name='sign_up_your_account'),
    path('message/', views.message, name='message'),
    path('create_message/', views.create_message, name='create_message'),
    path('login/', views.login, name='login'),
    path('messages/', views.messages, name='messages'),
    path('<str:name>_author/', views.author, name='author'),
    path('<int:id>_message_detail/', views.detail_of_message, name='detail_of_message')
]

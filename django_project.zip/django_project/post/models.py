from django.db import models


class Post(models.Model):
    name = models.CharField('Name', max_length=50)
    title = models.CharField('Title', max_length=50)
    text = models.TextField('Text')
    date = models.DateTimeField('Date of publication')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Пост'
        verbose_name_plural = 'Пости'


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    name = models.CharField('Name', max_length=50)
    comment_text = models.CharField('Text of comment', max_length=200)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'Коментар'
        verbose_name_plural = 'Коментарі'


class People(models.Model):
    login = models.CharField('Login', max_length=50)
    password = models.CharField('Password', max_length=15)

    def __str__(self):
        return self.login

    class Meta:
        verbose_name = 'Акаунт'
        verbose_name_plural = 'Акаунти'


class Message(models.Model):
    people = models.CharField('People', max_length=50)
    my_name = models.CharField('My name', max_length=50)
    text = models.TextField('Text')
    date = models.DateTimeField('Date of publication')

    def __str__(self):
        return self.people

    class Meta:
        verbose_name = 'Особисте повідомлення'
        verbose_name_plural = 'Особисті повідомлення'

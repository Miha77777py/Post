from django.contrib import admin

from .models import Post, Comment, People, Message

admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(People)
admin.site.register(Message)

from django.shortcuts import render
from django.http import Http404, HttpResponseRedirect
from django.utils.datastructures import MultiValueDictKeyError
from .models import Post, People, Message
from django.urls import reverse
import datetime
from django.db.models import Q


now = datetime.datetime.now()


def index(request):
    post_content = Post.objects.order_by('-date')
    return render(request, 'list.html', {'content': post_content})


def detail(request, id):
    try:
        i = Post.objects.get(id=id)
    except:
        raise Http404('Пост не знайдено')
    latest_comment = i.comment_set.order_by('-id')
    return render(request, 'detail.html', {'content': i, 'latest_comment': latest_comment})


def comment(request, id):
    try:
        i = Post.objects.get(id=id)
    except:
        raise Http404('Пост не знайдено')
    i.comment_set.create(name=request.POST['name'], comment_text=request.POST['text'])
    return HttpResponseRedirect(
        reverse(
            'posts:detail', args=(i.id,)
        )
    )


def author(request, name):
    post_content = Post.objects.filter(name=f'{name}').order_by('-date')
    return render(request, 'author.html', {'contents': name, 'post_content': post_content})


def search(request):
    request_post = str(request.POST["search"])
    post_content = Post.objects.filter(Q(text__icontains=f'{request_post.title()}')
                                       | Q(title__icontains=f'{request_post.title()}')
                                       | Q(text__icontains=f'{request_post.lower()}')
                                       | Q(title__icontains=f'{request_post.lower()}')
                                       | Q(text__icontains=f'{request_post.upper()}')
                                       | Q(title__icontains=f'{request_post.upper()}')
                                       )
    return render(request, 'search.html', {'content': post_content, 'request': request_post})


def create_post(request):
    try:
        account = People.objects.all()
        for i in account:
            if request.POST['password'] == i.password and request.POST['name'] == i.login:
                a = Post(name=request.POST['name'], title=request.POST['title'], text=request.POST['text'],
                         date=now.now()
                         )
                a.save()
                return HttpResponseRedirect(reverse('posts:index'))
        raise Http404('Вхід не виконано')
    except MultiValueDictKeyError:
        raise Http404('Ти не заповнив шаблон, а вже лізиш сюди! Так не піде!')


def create(request):
    return render(request, 'create.html')


def sign_up(request):
    return render(request, 'sign_up.html')


def sign_up_your_account(request):
    try:
        account = People.objects.all()
        for i in account:
            if request.POST['login'] == i.login:
                raise Http404('Вхід не виконано')
        p = People(login=request.POST['login'], password=request.POST['password'])
        p.save()
        return HttpResponseRedirect(reverse('posts:index'))
    except MultiValueDictKeyError:
        raise Http404('Ти не заповнив шаблон, а вже лізиш сюди! Так не піде!')


def message(request):
    return render(request, 'message.html')


def create_message(request):
    try:
        account = People.objects.all()
        for i in account:
            if request.POST['login'] == i.login and request.POST['password'] == i.password and \
                    request.POST['people'] != i.login:
                m = Message(people=request.POST['people'], text=request.POST['text'],
                            my_name=request.POST['login'], date=now.now()
                            )
                m.save()
                return HttpResponseRedirect(reverse('posts:index'))
        raise Http404('Вхід не виконано')
    except MultiValueDictKeyError:
        raise Http404('Ти не заповнив шаблон, а вже лізиш сюди! Так не піде!')


def login(request):
    return render(request, 'login.html')


def messages(request):
    try:
        account = People.objects.all()
        for i in account:
            if request.POST['password'] == i.password and request.POST['login'] == i.login:
                messages_ = Message.objects.filter(people=request.POST['login']).order_by('-date')
                if messages_:
                    return render(request, 'messages.html', {'messages_': messages_})
                else:
                    raise Http404('Повідомленнь не знайдено')
        raise Http404('Вхід не виконано')
    except MultiValueDictKeyError:
        raise Http404('Ти не заповнив шаблон, а вже лізиш сюди! Так не піде!')


def detail_of_message(request, id):
    try:
        i = Message.objects.get(id=id)
    except:
        raise Http404('Аккаунт не знайдено')
    return render(request, 'detail_of_message.html', {'content': i})
